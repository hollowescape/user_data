from django.contrib import admin
from django.urls import path
from enroll import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.add_show, name='add_show'),
    path('delete/<int:id>/', views.delete_data, name='delete_data'),
    path('update/<int:id>/', views.update_data, name='update_data'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
