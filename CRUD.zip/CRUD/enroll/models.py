from django.db import models

class User(models.Model):
    name = models.CharField(max_length=70)
    number = models.CharField(max_length=15)  # Adjust max_length as needed
    age = models.PositiveIntegerField()
    photo = models.ImageField(upload_to='media/', blank=True, null=True)  # Photo field

    def __str__(self):
        return self.name
